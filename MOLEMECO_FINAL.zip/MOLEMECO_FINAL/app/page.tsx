'use client';

import { useEffect, useMemo, useState } from 'react';
import QRCodeCard from '@/components/QRCodeCard';
import { createClient } from '@/lib/supabase/client';
import { makeCode, validHttpUrl } from '@/lib/code';
import type { QRCodeRow } from '@/lib/types';

export default function Dashboard() {
  const [userEmail, setUserEmail] = useState('');
  const [rows, setRows] = useState<QRCodeRow[]>([]);
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(true);

  async function load() {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { window.location.href = '/login'; return; }
    setUserEmail(user.email ?? '');
    const { data, error } = await supabase.from('qr_codes').select('*').order('created_at', { ascending: false });
    if (error) setMessage(error.message); else setRows((data ?? []) as QRCodeRow[]);
    setBusy(false);
  }

  useEffect(() => { void load(); }, []);

  const active = useMemo(() => rows.filter(r => r.active).length, [rows]);
  const scans = useMemo(() => rows.reduce((sum, r) => sum + Number(r.scan_count || 0), 0), [rows]);

  async function createQR() {
    if (!name.trim()) return setMessage('Give the shirt a name.');
    if (!validHttpUrl(url.trim())) return setMessage('Use a complete http:// or https:// link.');
    setMessage('');
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const row = { owner_id: user.id, code: makeCode(), name: name.trim(), destination_url: url.trim(), active: true };
    const { data, error } = await supabase.from('qr_codes').insert(row).select().single();
    if (error) return setMessage(error.message);
    setRows(current => [data as QRCodeRow, ...current]);
    setName(''); setUrl(''); setMessage('QR created.');
  }

  async function updateLink(code: string, destination_url: string) {
    if (!validHttpUrl(destination_url)) return setMessage('Use a complete http:// or https:// link.');
    const supabase = createClient();
    const { error } = await supabase.from('qr_codes').update({ destination_url }).eq('code', code);
    if (error) return setMessage(error.message);
    setRows(current => current.map(r => r.code === code ? { ...r, destination_url, updated_at: new Date().toISOString() } : r));
    setMessage('Destination updated.');
  }

  async function toggle(code: string) {
    const row = rows.find(r => r.code === code); if (!row) return;
    const supabase = createClient();
    const { error } = await supabase.from('qr_codes').update({ active: !row.active }).eq('code', code);
    if (error) return setMessage(error.message);
    setRows(current => current.map(r => r.code === code ? { ...r, active: !r.active } : r));
  }

  async function remove(code: string) {
    if (!window.confirm('Delete this QR code? This cannot be undone.')) return;
    const supabase = createClient();
    const { error } = await supabase.from('qr_codes').delete().eq('code', code);
    if (error) return setMessage(error.message);
    setRows(current => current.filter(r => r.code !== code));
  }

  async function logout() { await createClient().auth.signOut(); window.location.href = '/login'; }

  if (busy) return <main className="center"><div className="brand">MOLEMECO</div></main>;

  return <main className="shell">
    <header className="top"><div className="brand">MOLEMECO</div><div className="actions" style={{margin:0}}><span className="pill">LIVE</span><button className="btn secondary" onClick={logout}>Log out</button></div></header>
    <section className="hero"><h1>One QR. Change it anytime.</h1><p className="muted">Print the MOLEMECO QR once. Later, change where it sends people without reprinting the shirt.</p></section>
    {message && <div className="toast">{message}</div>}
    <section className="stats"><div className="card"><div className="label">QR codes</div><div className="stat">{rows.length}</div></div><div className="card"><div className="label">Active</div><div className="stat">{active}</div></div><div className="card"><div className="label">Scans</div><div className="stat">{scans}</div></div><div className="card"><div className="label">Account</div><div className="small" style={{marginTop:8,wordBreak:'break-word'}}>{userEmail}</div></div></section>
    <section className="card" style={{marginTop:16}}><h2 style={{marginTop:0}}>Create a shirt QR</h2><p className="small">The printed QR will always point to MOLEMECO, not directly to your destination.</p><div className="grid"><input className="input" placeholder="Shirt name" value={name} onChange={e => setName(e.target.value)} /><input className="input" placeholder="https://example.com" value={url} onChange={e => setUrl(e.target.value)} /></div><div className="actions"><button className="btn" onClick={createQR}>Create QR</button><a className="btn secondary" href="/profile">Public page</a></div></section>
    <section style={{marginTop:18}}><div className="between"><h2 style={{margin:0}}>Your QR codes</h2><span className="small">Only your account can manage these</span></div><div className="list" style={{marginTop:12}}>{rows.length === 0 ? <div className="card"><p style={{margin:0}}>No QR codes yet. Create your first shirt QR above.</p></div> : rows.map(row => <QRCodeCard key={row.id} row={row} onChange={updateLink} onToggle={toggle} onDelete={remove} />)}</div></section>
    <div className="footer">MOLEMECO • Dynamic QR platform</div>
  </main>;
}
