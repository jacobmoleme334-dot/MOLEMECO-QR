'use client';

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const [mode, setMode] = useState<'login'|'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (!email || password.length < 6) return setMessage('Enter an email and a password of at least 6 characters.');
    setBusy(true); setMessage('');
    const supabase = createClient();
    const result = mode === 'login' ? await supabase.auth.signInWithPassword({ email, password }) : await supabase.auth.signUp({ email, password });
    setBusy(false);
    if (result.error) return setMessage(result.error.message);
    if (mode === 'signup') return setMessage('Account created. If email confirmation is enabled, check your inbox, then log in.');
    window.location.href = '/';
  }

  return <main className="center"><div className="card auth"><div className="brand">MOLEMECO</div><h1>{mode === 'login' ? 'Welcome back.' : 'Create your account.'}</h1><p className="muted">Your QR codes belong to your account and can be managed from your phone.</p>{message && <div className="toast">{message}</div>}<div className="list"><input className="input" type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} /><input className="input" type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} /><button className="btn" disabled={busy} onClick={submit}>{busy ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Create account'}</button><button className="btn secondary" onClick={() => {setMode(mode === 'login' ? 'signup' : 'login');setMessage('')}}>{mode === 'login' ? 'Create an account' : 'I already have an account'}</button></div></div></main>;
}
