export default async function QRStatusPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const params = await searchParams;
  const message = params.error === 'setup' ? 'This QR is waiting for MOLEMECO to finish connecting.' : params.error === 'inactive' ? 'This QR code is disabled or does not exist.' : 'This QR code could not be opened.';
  return <main className="preview"><div><div className="brand">MOLEMECO</div><h1>{message}</h1><p className="muted">If you own this QR, open your dashboard to check its status.</p></div></main>;
}
