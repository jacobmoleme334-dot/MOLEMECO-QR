import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function GET(request: NextRequest, context: { params: Promise<{ code: string }> }) {
  const { code } = await context.params;
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const publishableKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  const origin = new URL(request.url).origin;

  if (!supabaseUrl || !publishableKey) return NextResponse.redirect(new URL(`/t/${encodeURIComponent(code)}?error=setup`, origin));

  const supabase = createClient(supabaseUrl, publishableKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data, error } = await supabase.rpc('resolve_qr', { p_code: code, p_user_agent: request.headers.get('user-agent'), p_referrer: request.headers.get('referer') });

  if (error || !data?.length || !data[0].active) return NextResponse.redirect(new URL(`/t/${encodeURIComponent(code)}?error=inactive`, origin));
  const destination = String(data[0].destination_url ?? '');
  if (!/^https?:\/\//i.test(destination)) return NextResponse.redirect(new URL(`/t/${encodeURIComponent(code)}?error=inactive`, origin));
  return NextResponse.redirect(destination, 302);
}
