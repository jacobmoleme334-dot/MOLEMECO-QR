'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import type { QRCodeRow } from '@/lib/types';

export default function ProfilePage() {
  const [rows, setRows] = useState<QRCodeRow[]>([]);
  useEffect(() => { (async () => { const { data: { user } } = await createClient().auth.getUser(); if (!user) { window.location.href = '/login'; return; } const { data } = await createClient().from('qr_codes').select('*').eq('owner_id', user.id).eq('active', true).order('created_at', { ascending: false }); setRows((data ?? []) as QRCodeRow[]); })(); }, []);
  return <main className="preview"><div className="profile"><div className="brand">MOLEMECO</div><h1>My shirt links</h1><p className="muted">Public-style preview of your active shirt destinations.</p>{rows.map(row => <a className="linkcard" href={row.destination_url} key={row.id}><strong>{row.name}</strong><div className="small" style={{marginTop:5,wordBreak:'break-word'}}>{row.destination_url}</div></a>)}{rows.length === 0 && <div className="card">No active shirt links yet.</div>}<a className="btn secondary" style={{marginTop:18}} href="/">Back to dashboard</a></div></main>;
}
