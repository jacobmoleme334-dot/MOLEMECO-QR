# MOLEMECO

MOLEMECO is a mobile-first dynamic QR platform for shirts.

## What it does
- Each shirt gets a permanent MOLEMECO QR URL: `/t/CODE`.
- The QR does **not** point directly to the destination.
- The server resolves the code through Supabase and redirects to the current destination.
- The owner can change the destination later without reprinting the shirt.
- Supabase Row Level Security limits QR management to the signed-in owner.
- QR scans increment the counter and create scan events.

## Required environment variables
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

## Deployment
Use Vercel with this repository as a Next.js project. Root directory is the repository root. Build command is `next build`.

## Supabase
The database should contain `profiles`, `qr_codes`, and `scan_events`, with the `resolve_qr(text,text,text)` RPC installed and executable by `anon` and `authenticated`.
