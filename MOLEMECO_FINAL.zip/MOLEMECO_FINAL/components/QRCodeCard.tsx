'use client';

import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import type { QRCodeRow } from '@/lib/types';

export default function QRCodeCard({ row, onChange, onToggle, onDelete }: { row: QRCodeRow; onChange: (code: string, url: string) => Promise<void>; onToggle: (code: string) => Promise<void>; onDelete: (code: string) => Promise<void>; }) {
  const [src, setSrc] = useState('');
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(row.destination_url);
  const [saving, setSaving] = useState(false);
  const qrUrl = typeof window === 'undefined' ? `/t/${row.code}` : `${window.location.origin}/t/${row.code}`;

  useEffect(() => { QRCode.toDataURL(qrUrl, { width: 900, margin: 2, errorCorrectionLevel: 'H' }).then(setSrc).catch(() => setSrc('')); }, [qrUrl]);

  async function save() { setSaving(true); await onChange(row.code, value.trim()); setSaving(false); setEditing(false); }
  function download() { if (!src) return; const a = document.createElement('a'); a.href = src; a.download = `molemeco-${row.code}.png`; a.click(); }

  return <article className="card">
    <div className="between"><div><div className="label">QR ID</div><strong>{row.code}</strong><div className="small">{row.name}</div></div><span className="pill">{row.active ? 'ACTIVE' : 'DISABLED'}</span></div>
    <div style={{marginTop:16}}><div className="qrbox">{src && <img src={src} alt={`MOLEMECO QR ${row.code}`} />}</div></div>
    <div className="small" style={{marginTop:10,wordBreak:'break-word'}}>Sends to: {row.destination_url}</div><div className="small" style={{marginTop:5}}>Scans: {Number(row.scan_count || 0)}</div>
    {editing ? <div style={{marginTop:12}}><input className="input" value={value} onChange={e => setValue(e.target.value)} /><div className="actions"><button className="btn" disabled={saving} onClick={save}>{saving ? 'Saving…' : 'Save link'}</button><button className="btn secondary" onClick={() => { setValue(row.destination_url); setEditing(false); }}>Cancel</button></div></div> : <div className="actions"><button className="btn" onClick={() => setEditing(true)}>Change link</button><button className="btn secondary" onClick={download}>Download PNG</button><button className="btn secondary" onClick={() => window.print()}>Print</button><button className="btn secondary" onClick={() => onToggle(row.code)}>{row.active ? 'Disable' : 'Enable'}</button><button className="btn danger" onClick={() => onDelete(row.code)}>Delete</button></div>}
  </article>;
}
