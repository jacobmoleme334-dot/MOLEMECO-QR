export type QRCodeRow = {
  id: string;
  owner_id: string;
  code: string;
  name: string;
  destination_url: string;
  active: boolean;
  scan_count: number;
  created_at: string;
  updated_at: string;
};
